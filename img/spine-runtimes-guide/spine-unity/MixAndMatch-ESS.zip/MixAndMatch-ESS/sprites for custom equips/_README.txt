These custom equips were created by opening the template image in Photoshop, then drawing over the template shape on a separate layer.

For REGION ATTACHMENTS (plain rectanglular image attachments):
======================
If you make sure the images are exactly the same width and height, no extra work needs to be done.
With this in mind, it's best to have your template images have some extra padding, especially in the direction where you expect things to be bigger.

Using images that have slightly different width or height will move it off alignment accordingly. The tolerances and negative visual effect will depend on the art style and skeleton's construction.

If you need to use an image that's bigger (eg, for a longer sword), you can do that, but code needs to be added to adjust the pivot/offset for each attachment that diverges from the template's alignment.


For MESH ATTACHMENTS
====================
You must make sure the images have the same width and height.
With this in mind, it's best to have your template images have some extra padding, especially in the direction where you expect things to be bigger. And when modeling the mesh, make sure to include the extra padding within its shape.